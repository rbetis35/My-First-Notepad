import usuarios.usuario as modelo
import notas.acciones

class Acciones:

    def registro(self):
        print ("\nVamos a registrarte en el sistema")

        nombre = input("¿Cual es tu nombre?: ")
        apellidos = input("¿Cual o cuales son tus apellidos?: ")
        mail = input("Introduce tu mail: ")
        password = input("Introduce tu clave: ")

        usuario = modelo.usuario(nombre, apellidos, mail, password)
        registro = usuario.registrar()

        if registro[0] >= 1:
            print(f"\nPerfecto {registro[1].nombre}, te has registrado con el mail {registro[1].mail}")
        else:
            print("No te has registrado de manera correcta")

    def login(self):
        print ("\nIdentificate en el sistema")

        try:
            mail = input("Introduce tu mail: ")
            password = input("Introduce tu clave: ")

            usuario = modelo.usuario('','',mail,password)
            login = usuario.identificar()

            if mail == login[3]:
                print(f"\nBienvenido al sistema, {login[1]}, te has registrado en el sistema el día {login[5]}")
                self.proximasacciones(login)
                
        except Exception as e:
            #print(type(e))
            #print(type(e).__name__)
            print(f"Conexion incorrecta")

    def proximasacciones(self,usuario):
        print("""
        Acciones disponibles:
              - Crear nota (crear)
              - Mostrar notas (mostrar)
              - Eliminar alguna nota (eliminar)
              - Salir de la aplicacion (salir)
              """)
        
        accion = input("¿Que quieres hacer?: ")
        hazEl = notas.acciones.Acciones()

        if accion == "crear":
            print("Vamos a crear")
            hazEl.crear(usuario)
            self.proximasacciones(usuario)

        elif accion == "mostrar":
            print("Vamos a mostrar")
            hazEl.mostrar(usuario)
            self.proximasacciones(usuario)

        elif accion == "eliminar":
            print("Vamos a eliminar")
            hazEl.borrar(usuario)
            self.proximasacciones(usuario)

        elif accion == "salir":
            print(f"Ok {usuario[1]}, hasta pronto")
            exit()

        return None
        